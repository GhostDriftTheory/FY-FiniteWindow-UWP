# Finite-Window Replacement of Global Prime Sums: Cost–Accuracy Evidence for Fejér–Yukawa UWP

本リポジトリは、有限窓（Fejér–Yukawa, FY）とFFT畳込みによる**素数和の低コスト置換**の再現パッケージです。

## ディレクトリ構成
```
FY-FiniteWindow-UWP/
├─ report/    : Wordレポート（.docx）と同内容のMarkdown（.md）
├─ data/      : 実験CSV（スケーリング／ウィンドウ比較）
├─ figures/   : 図1–4（再生成も可能）
├─ code/      : 再描画・集計スクリプト（plot_results.py / compute_metrics.py）
├─ docs/      : REPRODUCIBILITY.md, DATA_DICTIONARY.md
└─ notebooks/ : 任意（Jupyter）
```

## クイック再現
```bash
pip install -r code/requirements.txt
python code/plot_results.py data/scaling_experiments_FY_FFT_memoized.csv data/window_pareto_memoized.csv --outdir figures/
python code/compute_metrics.py data/scaling_experiments_FY_FFT_memoized.csv data/window_pareto_memoized.csv --out report/metrics_summary.txt
```

- 図1–4が `figures/` に生成されます。
- 集計（表1・表2相当）が `report/metrics_summary.txt` に出力されます。

作成日: 2025-10-28
