#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def savefig(fig, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches='tight', dpi=180)

def plot_classical_scaling(df, outdir):
    df = df.dropna(subset=['classical_time_s']).copy()
    if 'T_count' not in df.columns:
        # backward compat
        df['T_count'] = df['|T|'] if '|T|' in df.columns else 0
    x = np.log10(df['N'].astype(float) * df['T_count'].astype(float).replace({0:np.nan}))
    y = np.log10(df['classical_time_s'].astype(float).replace({0:np.nan}))
    fig, ax = plt.subplots()
    ax.scatter(x, y, s=34)
    if x.size >= 2:
        A = np.vstack([x, np.ones_like(x)]).T
        m, b = np.linalg.lstsq(A, y, rcond=None)[0]
        xx = np.linspace(np.nanmin(x), np.nanmax(x), 100)
        ax.plot(xx, m*xx+b, linestyle='--')
        ax.set_title(f"Classical scaling (slope≈{m:.2f})")
    else:
        ax.set_title("Classical scaling")
    ax.set_xlabel("log10(N·|T|)")
    ax.set_ylabel("log10(time [s])")
    savefig(fig, Path(outdir)/"fig1_classical_scaling.png")

def plot_finitewindow_scaling(df, outdir):
    df = df.dropna(subset=['total_window_time_s']).copy()
    if 'T_count' not in df.columns:
        df['T_count'] = df['|T|'] if '|T|' in df.columns else 0
    size = np.log10(df['M_bins'].astype(float)*(df['Gamma'].astype(float)+df['T_count'].astype(float)).replace({0:np.nan}))
    y = np.log10(df['total_window_time_s'].astype(float).replace({0:np.nan}))
    fig, ax = plt.subplots()
    ax.scatter(size, y, s=34)
    if size.size >= 2:
        A = np.vstack([size, np.ones_like(size)]).T
        m, b = np.linalg.lstsq(A, y, rcond=None)[0]
        xx = np.linspace(np.nanmin(size), np.nanmax(size), 100)
        ax.plot(xx, m*xx+b, linestyle='--')
        ax.set_title(f"Finite-window (FFT) scaling (slope≈{m:.2f})")
    else:
        ax.set_title("Finite-window (FFT) scaling")
    ax.set_xlabel("log10(M·(Γ+|T|))")
    ax.set_ylabel("log10(time [s])")
    savefig(fig, Path(outdir)/"fig2_finite_window_scaling.png")

def plot_window_pareto(df_p, outdir):
    fig, ax = plt.subplots()
    for w in df_p['window'].dropna().unique():
        d = df_p[df_p['window']==w]
        ax.scatter(d['total_window_time_s'], d['rel_l2_error'], label=w, s=42)
    ax.set_xlabel("time [s] (finite window)")
    ax.set_ylabel("relative L2 error")
    ax.legend()
    ax.set_title("Pareto (time vs error)")
    savefig(fig, Path(outdir)/"fig3_window_pareto.png")

def plot_waveform_overlay_placeholder(outdir):
    import numpy as np
    fig, ax = plt.subplots()
    t = np.linspace(5, 40, 48)
    ax.plot(t, np.cos(t/2.0), label="Classical (placeholder)")
    ax.plot(t, 0.985*np.cos(t/2.0), linestyle="--", label="Finite-window FY (placeholder)")
    ax.set_xlabel("t")
    ax.set_ylabel("S(t) (normalized)")
    ax.legend()
    ax.set_title("Waveform overlay (placeholder)")
    savefig(fig, Path(outdir)/"fig4_waveform_overlay.png")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scaling_csv")
    ap.add_argument("pareto_csv")
    ap.add_argument("--outdir", default="figures")
    args = ap.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    df_scal = pd.read_csv(args.scaling_csv)
    df_par  = pd.read_csv(args.pareto_csv)
    plot_classical_scaling(df_scal, outdir)
    plot_finitewindow_scaling(df_scal, outdir)
    plot_window_pareto(df_par, outdir)
    plot_waveform_overlay_placeholder(outdir)

if __name__ == "__main__":
    main()
