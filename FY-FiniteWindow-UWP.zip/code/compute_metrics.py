#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path

def summarize_scaling(df):
    cols = ["N","T_count","Gamma"]
    if "T_count" not in df.columns and "|T|" in df.columns:
        df = df.rename(columns={"|T|":"T_count"})
    agg = df.groupby(cols, dropna=False).agg({
        "classical_time_s":"mean",
        "total_window_time_s":"mean"
    }).reset_index()
    return agg

def pareto_best(df):
    best_rows = []
    for g, d in df.groupby("Gamma"):
        d = d.sort_values(["rel_l2_error","total_window_time_s"])
        if len(d)>0:
            best_rows.append(d.iloc[0])
    return pd.DataFrame(best_rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scaling_csv")
    ap.add_argument("pareto_csv")
    ap.add_argument("--out", default="report/metrics_summary.txt")
    args = ap.parse_args()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df_scal = pd.read_csv(args.scaling_csv)
    df_par  = pd.read_csv(args.pareto_csv)
    agg = summarize_scaling(df_scal)
    best = pareto_best(df_par)
    with open(out, "w", encoding="utf-8") as f:
        f.write("# スケーリング要約（平均時間）\n")
        f.write(agg.to_string(index=False))
        f.write("\n\n# パレート最良（Γ別、誤差最小→時間最小）\n")
        f.write(best.to_string(index=False))

if __name__ == "__main__":
    main()
