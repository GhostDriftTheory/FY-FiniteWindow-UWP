# REPRODUCIBILITY
環境: Python >=3.9, numpy, pandas, matplotlib
```
pip install -r code/requirements.txt
python code/plot_results.py data/scaling_experiments_FY_FFT_memoized.csv data/window_pareto_memoized.csv --outdir figures/
python code/compute_metrics.py data/scaling_experiments_FY_FFT_memoized.csv data/window_pareto_memoized.csv --out report/metrics_summary.txt
```

出力:
- figures/fig1_classical_scaling.png
- figures/fig2_finite_window_scaling.png
- figures/fig3_window_pareto.png
- figures/fig4_waveform_overlay.png
- report/metrics_summary.txt
