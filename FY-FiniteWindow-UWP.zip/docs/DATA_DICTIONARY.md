# DATA_DICTIONARY

## scaling_experiments_FY_FFT_memoized.csv
N, M_bins, sigma, T_count, Gamma, window, prep_time_s, classical_time_s, bin_time_s, conv_time_s, eval_time_s, total_window_time_s, rel_l2_error

## window_pareto_memoized.csv
window, Gamma, total_window_time_s, rel_l2_error, N, T_count, M_bins, sigma
